

export interface JwtPayload {
    id: string;

    // TODO: añadir todo lo que quieran grabar.
}
